package controller;

import entity.MenuItem1;

public interface MenuController1 {
	
	    void displayMenu();
	    void addNewMenuItem(MenuItem1 item);
	    void updateMenuItem(MenuItem1 item);
	}



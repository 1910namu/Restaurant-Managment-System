package controller;

import java.util.List;

import dao.MenuDao;
import dao.MenuDao1;
import entity.MenuItem1;

public class MenuController implements MenuController1{
	
	    private MenuDao1 menuDao;

	    public MenuController(MenuDao menuDao) {
	        this.menuDao = menuDao;
	    }

	    @Override
	    public void displayMenu() {
	        List<MenuItem1> menuItems = menuDao.getMenuItems();
	        System.out.println("Menu Items:");
	        for (MenuItem1 item : menuItems) {
	            System.out.println(item.getName() + " - Rs" + item.getPrice());
	        }
	    }

		@Override
		public void addNewMenuItem(MenuItem1 item) {
			menuDao.addMenuItem(item);
		}

	    @Override
	    public void updateMenuItem(MenuItem1 item) {
	        menuDao.updateMenuItem(item);
	    }

		
		
	}



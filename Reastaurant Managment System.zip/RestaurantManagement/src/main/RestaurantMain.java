package main;

import java.util.Scanner;

import controller.MenuController;
import dao.MenuDao;
import entity.MenuItem;

public class RestaurantMain {
	public static void main(String[] args) {
		// Create instances
		MenuDao menuDao = new MenuDao();
		MenuController menuController = new MenuController(menuDao);

		// Scanner for user input
		Scanner scanner = new Scanner(System.in);

		// Main loop
		boolean exit = false;
		while (!exit) {
			System.out.println("\nMenu Management System");
			System.out.println("1. Display Menu");
			System.out.println("2. Add Menu Item");
			System.out.println("3. Update Menu Item");
			System.out.println("4. Exit");
			System.out.print("Enter your choice: ");

			int choice = scanner.nextInt();
			scanner.nextLine(); // Consume the newline character

			switch (choice) {
			case 1:
				// Display menu
				menuController.displayMenu();
				break;
			case 2:
				// Add menu item
				System.out.print("Enter item name: ");
				String itemName = scanner.nextLine();
				System.out.print("Enter item price: ");
				double itemPrice = scanner.nextDouble();
				MenuItem newItem = new MenuItem(itemName, itemPrice);
				menuController.addNewMenuItem(newItem);
				break;
			case 3:
				// Update menu item
				System.out.print("Enter item name to update: ");
				String itemNameToUpdate = scanner.nextLine();
				System.out.print("Enter new item price: ");
				double newItemPrice = scanner.nextDouble();
				MenuItem updatedItem = new MenuItem(itemNameToUpdate, newItemPrice);
				menuController.updateMenuItem(updatedItem);
				break;
			case 4:
				// Exit the loop
				exit = true;
				break;
			default:
				System.out.println("Invalid choice. Please enter a number between 1 and 4.");
			}
		}

		// Close the scanner
		scanner.close();
	}
}

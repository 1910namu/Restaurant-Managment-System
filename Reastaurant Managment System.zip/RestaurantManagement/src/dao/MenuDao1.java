package dao;

import java.util.List;

import entity.MenuItem1;

public interface MenuDao1 {

	List<MenuItem1> getMenuItems();

	void addMenuItem(MenuItem1 item);

	void updateMenuItem(MenuItem1 item);
}

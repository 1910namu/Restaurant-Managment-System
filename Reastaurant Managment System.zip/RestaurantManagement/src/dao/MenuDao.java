package dao;

import java.util.ArrayList;
import java.util.List;

import entity.MenuItem;
import entity.MenuItem1;

public class MenuDao implements MenuDao1 {

	private List<MenuItem> menuItems;

	public MenuDao() {
		this.menuItems = new ArrayList<>();
	}

	@Override
	public List<MenuItem1> getMenuItems() {
		return new ArrayList<>(menuItems);
	}

	@Override
	public void addMenuItem(MenuItem1 item) {
		menuItems.add((MenuItem) item);
		System.out.println("Added: " + item.getName() + " - Rs" + item.getPrice());
	}

	@Override
	public void updateMenuItem(MenuItem1 item) {
		// Assuming the MenuItem is already in the menuItems list
		MenuItem existingItem = menuItems.stream().filter(i -> i.getName().equals(item.getName())).findFirst()
				.orElse(null);

		if (existingItem != null) {
			existingItem.setPrice(item.getPrice());
			System.out.println("Updated: " + item.getName() + " - Rs" + item.getPrice());
		}
	}

}

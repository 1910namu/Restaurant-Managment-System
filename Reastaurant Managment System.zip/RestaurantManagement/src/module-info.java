/**
 * 
 */
/**
 * 
 */
module RestaurantManagement {
}